import javax.swing.JApplet;


@SuppressWarnings("serial")
public class Applet extends JApplet{

	
	public void start(){
		
		new DisplayGUI();
	}
	
	public void init(){
		
		new DisplayGUI();
	}
	
}
